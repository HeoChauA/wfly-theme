<div class="fl-rich-text">
	<?php echo $settings->text; ?>
</div>