(function($) {

	$(function() {
	
		new FLBuilderAccordion({
			id: '<?php echo $id ?>'
		});
	});
	
})(jQuery);